import React, { useState } from "react";
import "./App.css";

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  return (
    <div className="App">
      <header className="App-header">
        <h1>Условный рендер</h1>
        <button className="button" onClick={() => setLoggedIn(!loggedIn)}>
          {loggedIn ? "Log out" : "Log in"}
        </button>
        {loggedIn ? <h1>Вы вошли.</h1> : <h1>Попытайтесь войти.</h1>}
      </header>
    </div>
  );
}

export default App;
