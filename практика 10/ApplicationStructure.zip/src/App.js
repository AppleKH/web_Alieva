import "./styles.css";
import Image from "./image";

export default function App() {
  return (
    <div className="App">
      <h1>Как музыка может улучшить качество нашей жизни?</h1>
      <h5>Музыка во все времена и в разных культурах играла очень важную роль. Наши предки погружались в нее и в горе, и в радости.</h5>
      {/* image from same dir */}
      <Image src={require("./music.jpg")} />
    </div>
  );
}
