import * as React from "react";
import { View } from "react-native";
import Slider from "./Slider";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showSplashScreen: true
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ showSplashScreen: false });
    }, 4000);
  }

  render() {
    return (
      <View>
        <Slider />
      </View>
    );
  }
}

export default App;
