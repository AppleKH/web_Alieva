import "./styles.css";
import Image from "./image";

export default function App() {
  return (
    <div className="App">
      <header role="banner" class="banner">
        <div class="head_box">
          <div class="site_name">
            <span class="text_name">НовыйМаркет.Покупки</span>
          </div>
        </div>
      </header>
      <img src="http://i.stack.imgur.com/SBv4T.gif" alt="" width="400" />
      <div class="box">
        <h1>Покупки на Маркете</h1>
        <div>
          <button>
            <Image src={require("./accessories.jpg")} />
          </button>
          <button>
            <Image src={require("./apteka.jpg")} />
          </button>
          <button>
            <Image src={require("./b_technika.jpg")} />
          </button>
          <button>
            <Image src={require("./beauty.jpg")} />
          </button>
          <button>
            <Image src={require("./books.jpg")} />
          </button>
          <button>
            <Image src={require("./clothers.jpg")} />
          </button>
          <button>
            <Image src={require("./computers.jpg")} />
          </button>
          <button>
            <Image src={require("./electronica.jpg")} />
          </button>
          <button>
            <Image src={require("./flowers.jpg")} />
          </button>
          <button>
            <Image src={require("./garden.jpg")} />
          </button>
          <button>
            <Image src={require("./gigiena.jpg")} />
          </button>
          <button>
            <Image src={require("./hobby.jpg")} />
          </button>
          <button>
            <Image src={require("./home.jpg")} />
          </button>
          <button>
            <Image src={require("./laptop.jpg")} />
          </button>
          <button>
            <Image src={require("./pets.jpg")} />
          </button>
          <button>
            <Image src={require("./products.jpg")} />
          </button>
          <button>
            <Image src={require("./school.jpg")} />
          </button>
          <button>
            <Image src={require("./smartfon.jpg")} />
          </button>
          <button>
            <Image src={require("./sport.jpg")} />
          </button>
          <button>
            <Image src={require("./toys.jpg")} />
          </button>
        </div>
      </div>
    </div>
  );
}
