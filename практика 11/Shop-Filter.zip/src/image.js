export default function Image({ src }) {
  return <img class="tovar" src={src} alt="icon" />;
}
